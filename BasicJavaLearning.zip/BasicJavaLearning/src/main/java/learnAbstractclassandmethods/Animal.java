package learnAbstractclassandmethods;

public abstract class Animal {

    public  abstract void dog();

    public  void cat(){
        System.out.println("Meowwwww");
    }




}
