package learnAbstractclassandmethods;

public class Zoo extends Animal{

    @Override
    public void dog() {
        System.out.println("Will bite if stranger comes");
    }


    public static void main(String[] args) {
        Zoo myobj = new Zoo();
        myobj.dog();
        myobj.cat();
    }
}
