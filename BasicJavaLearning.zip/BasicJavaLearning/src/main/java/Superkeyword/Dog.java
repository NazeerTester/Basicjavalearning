package Superkeyword;

public class Dog  extends Animal {

    //1.Superkeyword using instance variable


    String color = "black";
    void bark(){


        System.out.println(color);
        System.out.println(super.color);

    }



    public static void main(String[] args) {
        Dog d =new Dog();
        d.bark();



    }
}
