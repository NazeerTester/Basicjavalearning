package Superkeyword;

public class Father {

    //Super keyword using Methods
    public  void  Home(){

        System.out.println("Bungalow");
    }
}
