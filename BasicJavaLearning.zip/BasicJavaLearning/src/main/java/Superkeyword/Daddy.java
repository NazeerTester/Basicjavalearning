package Superkeyword;

public class Daddy {

    Daddy(){
        System.out.println("Daddy is good");
    }
}
