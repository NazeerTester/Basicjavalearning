package Superkeyword;

public class DirubaiAmbani {


    public  void reliancepetrolium(){
        System.out.println("Petro selling at cheap price");
    }
}
