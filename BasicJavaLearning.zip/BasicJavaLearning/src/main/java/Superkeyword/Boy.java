package Superkeyword;

public class Boy extends Daddy{

    Boy(){
      
        System.out.println("My boy");

    }



    public static void main(String[] args) {

        Boy B = new Boy();


    }
}
