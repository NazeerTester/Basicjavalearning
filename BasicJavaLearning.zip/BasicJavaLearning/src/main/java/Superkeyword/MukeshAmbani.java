package Superkeyword;

public class MukeshAmbani extends  DirubaiAmbani{


    @Override
    public void reliancepetrolium() {
        System.out.println("Petrol at premium quality");
    }

    public void petroldetails(){
        super.reliancepetrolium();
    }

    public static void main(String[] args) {

        MukeshAmbani bussiness = new MukeshAmbani();
        bussiness.petroldetails();

    }
}
