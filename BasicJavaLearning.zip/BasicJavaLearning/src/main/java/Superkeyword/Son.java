package Superkeyword;

public class Son extends Father {

    //Super keyword with methods
    public void car(){

        System.out.println("benz");
    }

    public void flight(){
        super.Home(); //parent class methid
        car(); //child class method
    }

    public void expensivehome(){

    }

    public static void main(String[] args) {
        Son s = new Son();
        s.flight();


    }
}
