package LearnConstructor;

public class Phone {


    String name;
    int i;

    public  Phone(String namdiff){
        name = namdiff;
            }
}
