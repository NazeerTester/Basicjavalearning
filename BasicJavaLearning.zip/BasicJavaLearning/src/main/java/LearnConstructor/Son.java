package LearnConstructor;

public class Son {


    public static void main(String[] args) {
        Godfather good = new Godfather("John" ,500);
        System.out.println(good.don);
        System.out.println(good.money);


    }
}
