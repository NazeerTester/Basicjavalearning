package LearnConstructor;

public class TestClass {

    public static void main(String[] args) {

        Testcontextsetup test = new Testcontextsetup("Testing",3);
        System.out.println(test.driver);

    }


}
