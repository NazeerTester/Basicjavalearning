package LearnConstructor;

public class Adidasshoe {

    public static void main(String[] args) {
        Shoes shoo = new Shoes("Black shoe" ,9);
        System.out.println(shoo.number);
        System.out.println(shoo.star);

    }





}
