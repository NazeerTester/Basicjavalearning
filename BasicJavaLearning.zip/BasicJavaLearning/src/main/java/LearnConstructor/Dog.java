package LearnConstructor;

public class Dog {

    String name;
    int num;
    public Dog(String name,int num){

       this.name=name;
       this.num=num;

    }




}
