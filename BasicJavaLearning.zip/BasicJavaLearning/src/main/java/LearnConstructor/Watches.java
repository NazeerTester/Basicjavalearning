package LearnConstructor;

public class Watches {

    public String color;

    public Watches(String color){

        this.color=color;

    }

    public static void main(String[] args) {
        Watches wat = new Watches("Black");



    }
}
