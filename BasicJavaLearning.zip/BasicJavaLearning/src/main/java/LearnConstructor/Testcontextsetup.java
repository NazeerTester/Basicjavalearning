package LearnConstructor;

public class Testcontextsetup {


    String driver;
    int numeric;

    public Testcontextsetup(String driver ,int numeric){
        this.driver=driver;
        this.numeric=numeric;

    }


}
