package LearnConstructor;

public class Appa {


    String rao;
    int kasu;


    public Appa(String rao,int kasu) {

        this.rao = rao;
        this.kasu = kasu;
    }

    public int show()
    {
            System.out.println(rao + " " + kasu);

        return 0;
    }

    int display(){
        System.out.println(kasu);
        return 0;
    }

    }

