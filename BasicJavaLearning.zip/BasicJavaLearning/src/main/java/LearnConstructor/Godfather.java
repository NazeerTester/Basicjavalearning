package LearnConstructor;

public class Godfather {


    String don;
    int money;


    public Godfather(String don, int money){

        this.don=don;
        this.money=money;

    }
}
