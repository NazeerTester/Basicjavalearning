package LearnConstructor;

public class Android {


    public static void main(String[] args) {
        Phone ph= new Phone("Android");
        System.out.println(ph.name);

    }
}
