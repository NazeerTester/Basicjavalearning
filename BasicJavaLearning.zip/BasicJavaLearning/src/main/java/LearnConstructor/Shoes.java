package LearnConstructor;

public class Shoes {


    String star;
    int number;

    public Shoes(String den ,int tell){

        star =den;
        number=tell;


    }


}
