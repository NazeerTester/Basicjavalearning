package LearnConstructor;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

public class Constructor {


    public static void main(String[] args) {
        Dog dog = new Dog("johnny",22);

        System.out.println(dog.name);
        System.out.println(dog.num);

    }



}
