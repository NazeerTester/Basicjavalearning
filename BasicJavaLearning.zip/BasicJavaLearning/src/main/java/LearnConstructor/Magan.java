package LearnConstructor;

public class Magan {

    public static void main(String[] args) {
        Appa ap=new Appa("Ramesh",200);

        System.out.println(ap.rao);
       System.out.println(ap.show());
        System.out.println(ap.display());
    }
}
