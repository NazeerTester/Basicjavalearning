package learnarray;

public class Foreachinstringarray {

    public static void main(String[] args) {


        //Creating an literal array
        String iamastring[] = {"nazeer","alex","vino"};


        // old way of array creation
        String std[] = new String[2];
                std[0]="nazeer bhai";


       //For each loop to traverse


        for (String element:
             iamastring) {
            System.out.println(element);

            //for loop to traverse

            for (int i=0; i<iamastring.length; i++){
                System.out.println(iamastring[i]);
            }

        }

    }
}
