package learnarray;

public class Integerarray {

    public static void main(String[] args) {

        // Old method of using arrays

  /*    int array[] = new int[3];
      array[0] = 10;
      array [1] = 20;
      array[2]=30;*/

        int array[]={22,33,33};

      for (int i=0; i<array.length; i++){
          System.out.println(array[i]);
      }
    }
}
