package learnarray;

import java.util.ArrayList;
import java.util.Arrays;

public class StringArray {


    public static void main(String[] args) {

      //String array
        String[] array = {"john","jerry","jose"};

        //Integet ayray
        Integer[] inter = {22,44,66};


       // System.out.println(array.length);

       // System.out.println(array[0]);  // print the first index

        for (int i=0; i< inter.length; i++) {
            System.out.println(i);
        }

            System.out.println("before printing direct i");


            //printing array[j]
            for (int j=0; j< inter.length;j++)
            {
                System.out.println(inter[j]);

        }
            System.out.println("After printing array[j]");


            //get an array length using length method
        System.out.println(array.length);

        //get the element of the array
      //  System.out.println(array[0]);

        //Set an element in array

        array[0] = "johny";
        System.out.println(array[0]);

        // to traverse on string array

        for(int i=0; i< array.length; i++){
            System.out.println(array[i]);
        }
 //Note : we cannot add or remove an element in array,since it is having  fixed length

        //Prrint an array
        System.out.println(array);

        //Printing in array is nOT useful,output wont look good
        //to get all the arrays we need to traverse through forloop
    }


    }


