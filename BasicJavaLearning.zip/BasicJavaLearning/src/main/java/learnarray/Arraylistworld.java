package learnarray;

import java.util.ArrayList;
import java.util.Arrays;

public class Arraylistworld {

    public static void main(String[] args) {


        // creating an element
        ArrayList<Object> ben = new ArrayList<>();
        ArrayList<String> listings = new ArrayList<>();


        //Addd an element
        ArrayList<String>  fed = new ArrayList<>(Arrays.asList("Alex" , "Nazeer" ,"Riyas"));

        //printing an arraylist
        System.out.println(fed);

        //Length of the array
        System.out.println(fed.size());

        //set and get an element
        fed.set(0,"vino");
        System.out.println(fed.get(0));

        //Remove an elelemnt
        fed.remove("Nazeer");
        System.out.println(fed.get(1));






    }
}


