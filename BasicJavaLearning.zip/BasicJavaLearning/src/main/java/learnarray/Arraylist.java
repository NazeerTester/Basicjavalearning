package learnarray;

import java.util.ArrayList;
import java.util.Arrays;

public class Arraylist {


    public static void main(String[] args) {

       // int[] lister = new int[]{22, 33};


        //Below we are nOT specifying the array size as it expansable or shirinked
        ArrayList<String> str = new ArrayList<>();
        ArrayList<String> str1 = new ArrayList<>();

        //Create an arraylist objects
        ArrayList<String> st2 = new ArrayList<>(Arrays.asList("john","jerry","jose"));

        st2.add("joker"); //add an element
        System.out.println(st2.add("jessie"));//add  an element and print it
        System.out.println(st2.get(3)); //get method will get the index position of the arraylist
        System.out.println(st2.size()); //size method will get size of the arraylist

   //Set an element and get an element

        st2.set(2,"josep campbell");
        System.out.println(st2.get(2));


        //Remove an element

        st2.remove("john");
        System.out.println(st2.get(0));

        //Print an arraylist
        System.out.println(st2);

        }



    }

