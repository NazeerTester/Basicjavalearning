package learnarray;

public class Arrayworld {

    public static void main(String[] args) {

        String[] watches = {"titan","casio","Timex"};

        String[] watches2 = new String[2];
        watches2[0]="seiko";
        watches2[1]="sonata";

       // System.out.println(watches);



        //traverse through loop
        for (String element:watches)
             {
                 System.out.println(element);
             }

        for(int i=0; i<watches.length; i++){
            System.out.println(watches[i]);
        }

        //set an element and get an element
        watches[0]="Rolex";
        System.out.println(watches[0]);

        //Fnding the length
        System.out.println(watches.length);




        }

    }

