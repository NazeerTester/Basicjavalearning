package interfacelearning;

import java.util.Scanner;

public class LearnScanner {

    //Get input from User

    public static void main(String[] args) {
        int a;
        int b;
        int c;

        Scanner console = new Scanner(System.in); //obecjt created

        System.out.println("Enter value of a ");
          a = console.nextInt();

        System.out.println("enter value of b ");
          b = console.nextInt();

          c = a + b;

        System.out.println("Total count of C is " + c);


    }
}
