package interfacelearning;

public interface Basicphone {


    public void calling();
    public void Incoming();
    public void bluetooth();
}
