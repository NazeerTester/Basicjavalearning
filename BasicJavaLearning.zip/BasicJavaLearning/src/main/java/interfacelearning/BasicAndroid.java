package interfacelearning;

public interface BasicAndroid {

    public  void camera();
}
