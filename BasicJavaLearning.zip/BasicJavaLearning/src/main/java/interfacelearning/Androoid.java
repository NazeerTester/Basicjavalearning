package interfacelearning;

public class Androoid implements Basicphone,BasicAndroid{

    @Override
    public void calling() {
        System.out.println("calling");
    }

    @Override
    public void Incoming() {
        System.out.println("Incoming call is working");
    }

    @Override
    public void bluetooth() {System.out.println("blue tooth works");
    }

    public  void internetaccess(){
        System.out.println("Internet is working");
    }

    public  void camera() {
        System.out.println("Awesome camera");
    }

    public static void main(String[] args) {
        Basicphone myobj = new Androoid();
        myobj.bluetooth();

        BasicAndroid myobj2=new Androoid();
        myobj2.camera();

        Androoid andy = new Androoid();
        andy.camera();



    }




    }

