package interfacelearn;

public class IndianTraffic implements CentralTraffic,AsiaTrafic{

    public static void main(String[] args) {

        CentralTraffic obj=new IndianTraffic(); //Obj for Interfaces methods
        obj.green();

        IndianTraffic iobj = new IndianTraffic(); // obj created for implementation class
        iobj.grey();

        AsiaTrafic  aobj=new IndianTraffic();
        aobj.bluesignal();

    }
    @Override
    public void green() {
        System.out.println("Green light showing");
    }

    @Override
    public void red() {

        System.out.println("Red light shwoing");

    }

    @Override
    public void yellow() {
        System.out.println("yellow light blinking");

    }

    public void grey(){
        System.out.println("grey light is new");
    }

    @Override
    public void bluesignal() {
        System.out.println("Blue signal");
    }
}
