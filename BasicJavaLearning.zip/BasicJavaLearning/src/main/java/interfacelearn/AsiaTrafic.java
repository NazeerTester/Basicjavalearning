package interfacelearn;

public interface AsiaTrafic {

    public void bluesignal();

}
