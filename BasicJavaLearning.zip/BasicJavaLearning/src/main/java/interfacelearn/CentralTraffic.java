package interfacelearn;

public interface CentralTraffic {

    public void green();
    public void red();
    public void yellow();
}
