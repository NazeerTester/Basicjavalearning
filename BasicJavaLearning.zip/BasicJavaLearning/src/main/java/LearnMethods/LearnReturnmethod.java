package LearnMethods;

public class LearnReturnmethod {


    int returnthemethod(){

        int a =10;
        int b = 20;
        int c = a + b;

        System.out.println(c);
        return c;
            
        }



    public static void main(String[] args) {

        LearnReturnmethod L = new LearnReturnmethod();
        L.returnthemethod();

    }
}
