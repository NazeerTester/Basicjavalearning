package LearnMethods;

public class Simplemethod {

    //Method with no arg

    void methodjolly(){
        System.out.println("No Argument in method");
    }

    void argmethod(int a ,int b){

        int c = a + b;
        System.out.println("Argument is here see with ur eyes " + c);
    }

    void argumethodwithstring(String a ,String b){

        System.out.println("I am a string " + a + b);

    }

    public static void main(String[] args) {
        Simplemethod S = new Simplemethod();
        S.methodjolly();
        S.argmethod(10,20);
        S.argumethodwithstring("Life is ","good");
    }
}
