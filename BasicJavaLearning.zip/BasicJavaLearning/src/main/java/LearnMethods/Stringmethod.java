package LearnMethods;

public class Stringmethod {

//Learn Stirngmethod

    // static String name ="Johnny NOT binny";

    public static void main(String[] args) {

        String name ="Johnny NOT binny";

        Stringmethod jav = new Stringmethod();

        System.out.println( "Name is " + name);
        System.out.println(name.length());
    }
}
