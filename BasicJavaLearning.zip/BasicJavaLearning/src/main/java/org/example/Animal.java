package org.example;

public class Animal{

    //1.Superkeyword using instance variable

  String color = "white";

}
