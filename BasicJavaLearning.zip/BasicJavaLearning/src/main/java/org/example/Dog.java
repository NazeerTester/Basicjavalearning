package org.example;

public class Dog  extends  Animal{


    String color = "black";
    void bark(){


        System.out.println(color);
        System.out.println(super.color);

    }



    public static void main(String[] args) {
        Dog d =new Dog();
        d.bark();



    }
}
