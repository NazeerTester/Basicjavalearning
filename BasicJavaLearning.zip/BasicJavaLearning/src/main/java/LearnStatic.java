public class LearnStatic {



    static int  a=10;

    public static void main(String[] args) {
        int b=20;

        
      //  LearnStatic l=new LearnStatic();
       // System.out.println(l.a);

        //we can avoid above obj creation mif we mention int a as static like static int a=10;

        System.out.println(a);
        
        //Static refers to class not methods
        //Any methods can refer the variable if it minetioned as static
        //Why static needed? using this we can avoid creating object and then using the global variables
    }
}
